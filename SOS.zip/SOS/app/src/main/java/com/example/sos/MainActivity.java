package com.example.sos;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;

import jcifs.CIFSContext;
import jcifs.config.PropertyConfiguration;
import jcifs.context.BaseContext;
import jcifs.smb.NtlmPasswordAuthenticator;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileOutputStream;

import java.util.Properties;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    private FusedLocationProviderClient fusedLocationClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button sosButton = findViewById(R.id.sos_button);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        sosButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "SOS Button Pressed");
                Toast.makeText(MainActivity.this, "REQUEST SENT", Toast.LENGTH_SHORT).show();
                getLocationAndSend();
            }
        });
    }

    private void getLocationAndSend() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            fusedLocationClient.getLastLocation()
                    .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            if (location != null) {
                                double latitude = location.getLatitude();
                                double longitude = location.getLongitude();
                                createFileAndUpload(latitude, longitude);
                            } else {
                                Toast.makeText(MainActivity.this, "Location not available", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }
    }

    private void createFileAndUpload(double latitude, double longitude) {
        File file = new File(getFilesDir(), "sos_location.txt");
        try (FileWriter writer = new FileWriter(file)) {
            writer.write("Latitude: " + latitude + ", Longitude: " + longitude);
            writer.flush();
            uploadFileToSamba(file);
        } catch (IOException e) {
            Log.e(TAG, "Error writing to file: " + e.getMessage(), e);
        }
    }

    private void uploadFileToSamba(File file) {
        try {
            String sambaPath = "smb://192.168.1.100/srv/samba/shared/sos_location.txt";

            // Create authentication credentials
            Properties properties = new Properties();
            properties.put("jcifs.smb.client.username", "sos");
            properties.put("jcifs.smb.client.password", "adas4321");
            CIFSContext baseContext = new BaseContext(new PropertyConfiguration(properties));
            CIFSContext authContext = baseContext.withCredentials(new NtlmPasswordAuthenticator("sos", "adas4321"));

            SmbFile smbFile = new SmbFile(sambaPath, authContext);

            try (SmbFileOutputStream smbOut = new SmbFileOutputStream(smbFile);
                 FileInputStream fis = new FileInputStream(file)) {
                byte[] buffer = new byte[1024];
                int length;
                while ((length = fis.read(buffer)) > 0) {
                    smbOut.write(buffer, 0, length);
                }
            }

            Log.d(TAG, "File sent successfully to Samba");
        } catch (Exception e) {
            Log.e(TAG, "Error sending file to Samba: " + e.getMessage(), e);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLocationAndSend();
            } else {
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}